﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net;
using System.Net.NetworkInformation;
using System.Net.Sockets;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Interop;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace simpleChatApp
{
    public partial class FormServer : Window
    {
        // Enable window dragging
        [DllImport("user32.dll")]
        public static extern bool ReleaseCapture();
        [DllImport("user32.dll")]
        public static extern bool SendMessage(IntPtr hwnd, int wMsg, int wParam, int lParam);

        protected override void OnMouseDown(MouseButtonEventArgs e)
        {
            base.OnMouseDown(e);
            ReleaseCapture();
            SendMessage(new WindowInteropHelper(this).Handle, 0x0112, 0xF010 + 0x0002, 0);
        }

        public FormServer()
        {
            InitializeComponent();

            // Auto-fill local IP address and default port number
            txtIP.Text = GetLocalIPv4();
            txtPort.Text = "8080";
        }

        private void BtnColose_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        }
        private void BtnConn_Click(object sender, RoutedEventArgs e)
        {
            StartServer();
        }
        private void BtnSending_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (clientSocket != null)
                {
                    Send(txtBox.Text);
                }
                else
                {
                    MessageBox.Show("Not connected to server.", "Error Message", MessageBoxButton.OK);
                    return;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error Message", MessageBoxButton.OK);
                return;
            }

            txtInfo.Text += ChatUtil.formatMessage("Me：" + txtBox.Text);
            txtBox.Clear();
        }


        private Socket serverSocket;
        private Socket clientSocket;
        private Dictionary<string, Socket> clientList = new Dictionary<string, Socket>();

        private void StartServer()
        {
            serverSocket = new Socket(AddressFamily.InterNetwork,
               SocketType.Stream, ProtocolType.Tcp);

            IPEndPoint point;
            try
            {
                point = new IPEndPoint(
                   IPAddress.Parse(txtIP.Text), int.Parse(txtPort.Text));
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Invalid IP address format.");
                return;
            }

            try
            {
                serverSocket.Bind(point);
                serverSocket.Listen(10);
                txtInfo.Text += (txtInfo.Text == "" ? 
                    "" : Environment.NewLine) + "Chat server started";
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error Message", MessageBoxButton.OK);
                return;
            }

            Task.Factory.StartNew(new Action(() =>
            {
                ListenSocket();
            }));

            txtIP.IsEnabled = txtPort.IsEnabled = false;
        }
        
        private void ListenSocket()
        {
            while (true)
            {
                try
                {
                    this.clientSocket = serverSocket.Accept();
                    var client = this.clientSocket.RemoteEndPoint.ToString();
                    Dispatcher.Invoke(() => {
                        txtInfo.Text += Environment.NewLine + client + " has entered the chat";
                    });

                    clientList.Add(client, this.clientSocket);
                    Task.Factory.StartNew(new Action(() =>
                    {
                        ReceiveMessage(this.clientSocket);
                    }));
                }
                catch
                {
                    Dispatcher.Invoke(() => {
                        txtInfo.Text += Environment.NewLine +  " has left the chat";
                    });

                    clientList.Clear();
                    txtIP.IsEnabled = txtPort.IsEnabled = true;

                    break;
                }
            }
        }

        private void ReceiveMessage(Socket Client)
        {
            while (true)
            {
                var buffer = new byte[1024 * 1024 * 10];
                var length = 0;
                var client = Client.RemoteEndPoint.ToString();
                try
                {
                    length = Client.Receive(buffer);
                }
                catch
                {
                    // Failed to connect
                    Dispatcher.Invoke(() => {
                        txtInfo.Text += Environment.NewLine + client + " has left the chat";
                    });
                    break;
                }
                if (length > 0)
                {
                    string message = Encoding.UTF8.GetString(buffer, 0, length - 0);
                    Dispatcher.Invoke(() =>
                    {
                        txtInfo.Text += Environment.NewLine + Environment.NewLine + DateTime.Now.ToString("HH:mm:ss")
                            + Environment.NewLine + client +  "：" + message;
                    });
                }
            }
        }

        private void Send(string value)
        {
            clientSocket.Send(Encoding.UTF8.GetBytes(value));
        }
        
        private string GetLocalIPv4()
        {
            string output = "";
            try
            {
                Process process = new Process();
                ProcessStartInfo startInfo = new ProcessStartInfo();
                startInfo.FileName = "cmd.exe";
                startInfo.Arguments = "/c ipconfig";
                startInfo.RedirectStandardOutput = true;
                startInfo.UseShellExecute = false;
                startInfo.CreateNoWindow = true;
                process.StartInfo = startInfo;
                process.Start();

                output = process.StandardOutput.ReadToEnd();
                process.WaitForExit();

                string[] ss = output.Split(Environment.NewLine.ToCharArray());
                string row = "";
                foreach (string s in ss)
                {
                    if (s.Contains("IPv4"))
                    {
                        row = s;
                        break;
                    }
                }
                return row.Length > 1 ? row.Split(':')[1].Trim() : "";
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return "";
            }
        }
    }
}
