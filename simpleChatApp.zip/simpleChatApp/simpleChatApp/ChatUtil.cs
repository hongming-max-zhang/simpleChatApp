﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace simpleChatApp
{
    internal static class ChatUtil
    {
        public static string formatMessage(string message)
        {
            return Environment.NewLine + Environment.NewLine + DateTime.Now.ToString("HH:mm:ss")
                + Environment.NewLine + message;
        }
    }
}
